module canadalink

go 1.27.0
