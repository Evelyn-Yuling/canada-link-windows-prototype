// Canada Link is a local launcher/configuration tool. All proxy transport is
// implemented by an unmodified, checksum-pinned official sing-box release.
package main

import (
	"archive/zip"
	"bufio"
	"bytes"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"math/big"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"time"
)

const version = "0.1.0-prototype"
const coreVersion = "1.14.4"
const coreURL = "https://github.com/SagerNet/sing-box/releases/download/v1.14.4/sing-box-1.14.4-windows-amd64.zip"
const archiveHash = "99185d75d314a07dbba4a130c8ad986cbeb629a07927975636b341ca61f991df"
const coreHash = "8f30682ee198855440d2a7fe070d5d3653793b2d01bb8c85eea88f93bbe7c8b9"
const certName = "canada-link.internal"

type M = map[string]any
type Invite struct {
	Version     int    `json:"version"`
	Host        string `json:"host"`
	Port        int    `json:"port"`
	Password    string `json:"password"`
	Certificate string `json:"certificate"`
	Expires     string `json:"expires"`
}

var reader = bufio.NewReader(os.Stdin)
var defaultDomains = []string{"openai.com", "chatgpt.com", "oaistatic.com", "oaiusercontent.com"}
var blockedIPs = []string{"0.0.0.0/8", "10.0.0.0/8", "100.64.0.0/10", "127.0.0.0/8", "169.254.0.0/16", "172.16.0.0/12", "192.0.0.0/24", "192.168.0.0/16", "198.18.0.0/15", "224.0.0.0/4", "240.0.0.0/4", "::/128", "::1/128", "::ffff:0:0/96", "64:ff9b::/96", "64:ff9b:1::/48", "2001::/32", "2002::/16", "fc00::/7", "fe80::/10", "ff00::/8"}

func main() {
	setupConsole()
	if len(os.Args) == 1 {
		menu()
		return
	}
	if err := dispatch(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, "未完成：", err)
		if strings.HasPrefix(os.Args[1], "run-") {
			prompt("按回车关闭此窗口", "")
		}
		os.Exit(1)
	}
}
func stateDir() string {
	if p := os.Getenv("CANADALINK_HOME"); p != "" {
		return p
	}
	if runtime.GOOS == "windows" {
		return filepath.Join(os.Getenv("LOCALAPPDATA"), "CanadaLink")
	}
	h, _ := os.UserHomeDir()
	return filepath.Join(h, ".local", "share", "canada-link")
}
func prompt(label, def string) string {
	fmt.Printf("%s", label)
	if def != "" {
		fmt.Printf(" [%s]", def)
	}
	fmt.Print(": ")
	s, _ := reader.ReadString('\n')
	s = strings.TrimSpace(s)
	if s == "" {
		return def
	}
	return s
}
func confirmed(message string) bool { return prompt(message+"，输入 YES 才继续", "") == "YES" }
func menu() {
	for {
		fmt.Printf("\nCanada Link %s\n本地试验版；不是已验证的跨境加速器。不会修改系统代理、路由、DNS、防火墙或 Tailscale。\n", version)
		fmt.Println("1 下载并校验官方代理内核\n2 加拿大端：生成配置\n3 中国端：导入连接文件\n4 加拿大端：启动服务\n5 中国端：启动本地代理\n6 中国端：打开专用 Edge 窗口\n7 检查配置与服务器证书\n8 Codex 桌面端：试验性启动（覆盖范围未验证）\n9 查看本地资料位置\n0 退出")
		var err error
		switch prompt("选择", "") {
		case "1":
			if confirmed("将从 SagerNet 官方 GitHub 下载 sing-box 1.14.4 到个人资料目录，不安装服务") {
				err = downloadCore()
			}
		case "2":
			err = setupServerInteractive()
		case "3":
			err = importClient(strings.Trim(prompt("连接文件完整路径", ""), "\""))
		case "4":
			if err = checkRole("server"); err == nil {
				err = spawnWindow("run-server")
			}
		case "5":
			if err = checkRole("client"); err == nil {
				err = spawnWindow("run-client")
			}
		case "6":
			err = browser(prompt("地址（该独立窗口的全部网页流量都走加拿大）", "https://chatgpt.com"), false)
		case "7":
			err = diagnose()
		case "8":
			fmt.Println("仅尝试给本次启动传入代理环境变量，不修改 Codex 文件。官方未保证涵盖桌面、插件、浏览器、WSL 的全部流量。请先完全退出 Codex。")
			if confirmed("接受此未验证范围后启动") {
				err = launchDesktop(strings.Trim(prompt("Codex/ChatGPT 桌面程序的实际 .exe 完整路径", ""), "\""))
			}
		case "9":
			fmt.Println(stateDir())
			fmt.Println("连接文件含密码，请勿发到聊天、公开网盘或代码仓库。")
		case "0":
			return
		default:
			continue
		}
		if err != nil {
			fmt.Println("未完成：", err)
		}
	}
}
func dispatch(a []string) error {
	switch a[0] {
	case "version":
		fmt.Println(version)
		return nil
	case "download-core":
		if len(a) != 2 || a[1] != "--accept-download" {
			return errors.New("请在菜单中确认下载，或明确传入 --accept-download")
		}
		return downloadCore()
	case "setup-server":
		if len(a) != 5 {
			return errors.New("用法 setup-server 公网IP或DDNS 外部端口 本机端口 本机监听IPv4")
		}
		p, e := strconv.Atoi(a[2])
		if e != nil {
			return e
		}
		l, e := strconv.Atoi(a[3])
		if e != nil {
			return e
		}
		return setupServer(a[1], p, l, a[4])
	case "import-client":
		if len(a) != 2 {
			return errors.New("用法 import-client 连接文件")
		}
		return importClient(a[1])
	case "run-server":
		return runCore("server")
	case "run-client":
		return runCore("client")
	case "check":
		return checkAll()
	case "diagnose":
		return diagnose()
	case "browser":
		u := "https://chatgpt.com"
		if len(a) > 1 {
			u = a[1]
		}
		return browser(u, false)
	case "browser-rules":
		u := "https://chatgpt.com"
		if len(a) > 1 {
			u = a[1]
		}
		return browser(u, true)
	case "desktop-experimental":
		if len(a) != 3 || a[1] != "--accept-unverified" {
			return errors.New("用法 desktop-experimental --accept-unverified 桌面程序.exe")
		}
		return launchDesktop(a[2])
	default:
		return errors.New("未知命令；不带参数启动可打开菜单")
	}
}
func validHost(h string) bool {
	if net.ParseIP(h) != nil {
		return true
	}
	if len(h) > 253 || !strings.Contains(h, ".") {
		return false
	}
	for _, s := range strings.Split(h, ".") {
		if len(s) == 0 || len(s) > 63 || !regexp.MustCompile(`^[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$`).MatchString(s) {
			return false
		}
	}
	return true
}
func writeNew(path string, b []byte) error {
	if e := os.MkdirAll(filepath.Dir(path), 0700); e != nil {
		return e
	}
	f, e := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		return e
	}
	defer f.Close()
	_, e = f.Write(b)
	return e
}
func jsonBytes(v any) []byte {
	b, e := json.MarshalIndent(v, "", "  ")
	if e != nil {
		panic(e)
	}
	return append(b, '\n')
}
func certPair() (string, string, time.Time, error) {
	k, e := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if e != nil {
		return "", "", time.Time{}, e
	}
	serial, e := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 128))
	if e != nil {
		return "", "", time.Time{}, e
	}
	expiry := time.Now().AddDate(1, 0, 0)
	c := &x509.Certificate{SerialNumber: serial, Subject: pkix.Name{CommonName: certName}, DNSNames: []string{certName}, NotBefore: time.Now().Add(-5 * time.Minute), NotAfter: expiry, KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}, BasicConstraintsValid: true}
	der, e := x509.CreateCertificate(rand.Reader, c, c, &k.PublicKey, k)
	if e != nil {
		return "", "", time.Time{}, e
	}
	key, e := x509.MarshalPKCS8PrivateKey(k)
	if e != nil {
		return "", "", time.Time{}, e
	}
	return string(pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})), string(pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: key})), expiry, nil
}
func validateInvite(v Invite) error {
	if v.Version != 1 || !validHost(v.Host) || v.Port < 1 || v.Port > 65535 {
		return errors.New("连接文件格式、地址或端口无效")
	}
	p, e := base64.RawURLEncoding.DecodeString(v.Password)
	if e != nil || len(p) != 32 {
		return errors.New("连接文件密码格式无效")
	}
	block, rest := pem.Decode([]byte(v.Certificate))
	if block == nil || block.Type != "CERTIFICATE" || len(bytes.TrimSpace(rest)) > 0 {
		return errors.New("连接文件必须仅包含一张服务器证书")
	}
	c, e := x509.ParseCertificate(block.Bytes)
	if e != nil {
		return errors.New("证书无效")
	}
	pool := x509.NewCertPool()
	pool.AddCert(c)
	_, e = c.Verify(x509.VerifyOptions{Roots: pool, DNSName: certName})
	if e != nil {
		return fmt.Errorf("证书校验失败：%w", e)
	}
	return nil
}
func setupServerInteractive() error {
	fmt.Println("只生成资料，不修改网络。建议加拿大路由器外部 TCP443 转发至本机 TCP24443；需另行确认公网可达、防火墙及远控安全。")
	h := prompt("加拿大公网IPv4或DDNS域名（不是路由器管理地址）", "")
	p, e := strconv.Atoi(prompt("路由器外部TCP端口", "443"))
	if e != nil {
		return e
	}
	l, e := strconv.Atoi(prompt("本机监听TCP端口", "24443"))
	if e != nil {
		return e
	}
	bind := prompt("本机监听IPv4（0.0.0.0 代表全部网卡；建议填加拿大LAN地址）", "")
	if !confirmed("将在个人资料目录生成私钥和连接密码；不会打开端口") {
		return nil
	}
	return setupServer(h, p, l, bind)
}
func setupServer(host string, externalPort, listenPort int, bind string) error {
	if !validHost(host) || externalPort < 1 || externalPort > 65535 || listenPort < 1024 || listenPort > 65535 {
		return errors.New("地址或端口无效；本机使用 1024–65535")
	}
	ip := net.ParseIP(bind)
	if ip == nil || ip.To4() == nil {
		return errors.New("请填写加拿大电脑的LAN IPv4；仅做本机实验可用 127.0.0.1")
	}
	dir := filepath.Join(stateDir(), "server")
	if _, e := os.Stat(dir); e == nil {
		return errors.New("服务器资料已存在，拒绝覆盖或自动轮换密钥")
	}
	cert, key, expiry, e := certPair()
	if e != nil {
		return e
	}
	p := make([]byte, 32)
	if _, e = rand.Read(p); e != nil {
		return e
	}
	v := Invite{1, host, externalPort, base64.RawURLEncoding.EncodeToString(p), cert, expiry.Format(time.RFC3339)}
	if e = validateInvite(v); e != nil {
		return e
	}
	if e = writeNew(filepath.Join(dir, "server-cert.pem"), []byte(cert)); e != nil {
		return e
	}
	if e = writeNew(filepath.Join(dir, "server-key.pem"), []byte(key)); e != nil {
		return e
	}
	if e = writeNew(filepath.Join(dir, "config.json"), jsonBytes(serverConfig(v, listenPort, bind))); e != nil {
		return e
	}
	export := filepath.Join(dir, "client-connection.SECRET.json")
	if e = writeNew(export, jsonBytes(v)); e != nil {
		return e
	}
	fmt.Println("已生成；未启动服务、未开放端口。把以下连接文件通过你已有的安全通道传到中国电脑：", export)
	fmt.Println("不要传 server-key.pem。证书到期：", expiry.Format("2006-01-02"))
	return nil
}
func serverConfig(v Invite, port int, bind string) M {
	return M{"log": M{"level": "warn", "timestamp": true}, "dns": M{"servers": []M{{"type": "local", "tag": "local-dns"}}}, "inbounds": []M{{"type": "trojan", "tag": "private-entry", "listen": bind, "listen_port": port, "users": []M{{"name": "owner", "password": v.Password}}, "tls": M{"enabled": true, "min_version": "1.2", "certificate_path": "server-cert.pem", "key_path": "server-key.pem"}}}, "outbounds": []M{{"type": "direct", "tag": "residential", "domain_resolver": M{"server": "local-dns", "strategy": "ipv4_only"}}}, "route": M{"default_domain_resolver": M{"server": "local-dns", "strategy": "ipv4_only"}, "rules": []M{{"network": "udp", "action": "reject"}, {"action": "resolve", "server": "local-dns", "strategy": "ipv4_only"}, {"ip_cidr": blockedIPs, "action": "reject"}, {"ip_is_private": true, "action": "reject"}}, "final": "residential"}}
}
func readInvite(path string) (Invite, error) {
	var v Invite
	f, e := os.Open(path)
	if e != nil {
		return v, e
	}
	defer f.Close()
	d := json.NewDecoder(io.LimitReader(f, 32769))
	d.DisallowUnknownFields()
	if e = d.Decode(&v); e != nil {
		return v, errors.New("连接文件JSON无效")
	}
	var extra any
	if e = d.Decode(&extra); e != io.EOF {
		return v, errors.New("连接文件含多余数据")
	}
	return v, validateInvite(v)
}
func importClient(path string) error {
	v, e := readInvite(path)
	if e != nil {
		return e
	}
	dir := filepath.Join(stateDir(), "client")
	if _, e = os.Stat(dir); e == nil {
		return errors.New("客户端资料已存在，拒绝覆盖；需要更新时先备份旧资料再明确更换")
	}
	if e = writeNew(filepath.Join(dir, "connection.SECRET.json"), jsonBytes(v)); e != nil {
		return e
	}
	if e = writeNew(filepath.Join(dir, "domains.txt"), []byte(strings.Join(defaultDomains, "\n")+"\n")); e != nil {
		return e
	}
	if e = writeNew(filepath.Join(dir, "config.json"), jsonBytes(clientConfig(v, defaultDomains))); e != nil {
		return e
	}
	fmt.Println("导入完成；未修改系统代理。端口 2081 全部经加拿大，端口 2080 仅名单域名经加拿大。")
	return nil
}
func clientConfig(v Invite, domains []string) M {
	return M{"log": M{"level": "warn", "timestamp": true}, "dns": M{"servers": []M{{"type": "local", "tag": "local-dns"}}}, "inbounds": []M{{"type": "http", "tag": "selected", "listen": "127.0.0.1", "listen_port": 2080}, {"type": "http", "tag": "canada-only", "listen": "127.0.0.1", "listen_port": 2081}}, "outbounds": []M{{"type": "trojan", "tag": "canada", "server": v.Host, "server_port": v.Port, "password": v.Password, "network": "tcp", "domain_resolver": "local-dns", "connect_timeout": "10s", "tls": M{"enabled": true, "server_name": certName, "min_version": "1.2", "certificate": []string{v.Certificate}}}, {"type": "direct", "tag": "direct", "domain_resolver": "local-dns"}}, "route": M{"rules": []M{{"inbound": []string{"canada-only"}, "action": "route", "outbound": "canada"}, {"domain_suffix": domains, "action": "route", "outbound": "canada"}}, "final": "direct"}}
}
func loadDomains(path string) ([]string, error) {
	b, e := os.ReadFile(path)
	if e != nil {
		return nil, e
	}
	if len(b) > 65536 {
		return nil, errors.New("域名表过大")
	}
	var out []string
	seen := map[string]bool{}
	for _, d := range strings.Split(string(b), "\n") {
		d = strings.ToLower(strings.TrimSpace(d))
		if d == "" || strings.HasPrefix(d, "#") {
			continue
		}
		if net.ParseIP(d) != nil || !validHost(d) {
			return nil, errors.New("域名表只接受域名，不接受网址、IP或通配符")
		}
		if !seen[d] {
			out = append(out, d)
			seen[d] = true
		}
	}
	if len(out) == 0 {
		return nil, errors.New("域名表为空")
	}
	return out, nil
}
func refreshClient() error {
	dir := filepath.Join(stateDir(), "client")
	v, e := readInvite(filepath.Join(dir, "connection.SECRET.json"))
	if e != nil {
		return e
	}
	d, e := loadDomains(filepath.Join(dir, "domains.txt"))
	if e != nil {
		return e
	}
	return atomicWrite(filepath.Join(dir, "config.json"), jsonBytes(clientConfig(v, d)))
}
func exePath() string { return filepath.Join(stateDir(), "core", "sing-box.exe") }
func hashFile(path string) (string, error) {
	f, e := os.Open(path)
	if e != nil {
		return "", e
	}
	defer f.Close()
	h := sha256.New()
	_, e = io.Copy(h, f)
	return hex.EncodeToString(h.Sum(nil)), e
}
func verifiedCore() (string, error) {
	if runtime.GOOS != "windows" {
		return "", errors.New("发布启动器仅在 Windows x64 运行；开发测试直接使用经校验的 Linux 内核")
	}
	p := exePath()
	h, e := hashFile(p)
	if e != nil {
		return "", errors.New("尚未下载官方内核；先选菜单 1")
	}
	if h != coreHash {
		return "", errors.New("内核校验失败，拒绝执行")
	}
	return p, nil
}
func downloadCore() error {
	if runtime.GOOS != "windows" || runtime.GOARCH != "amd64" {
		return errors.New("此下载器仅用于 Windows x64")
	}
	if p, e := verifiedCore(); e == nil {
		fmt.Println("已有经过校验的官方内核：", p)
		return nil
	}
	cli := &http.Client{Timeout: 5 * time.Minute, CheckRedirect: func(req *http.Request, via []*http.Request) error {
		if len(via) > 5 {
			return errors.New("重定向次数过多")
		}
		if req.URL.Scheme != "https" {
			return errors.New("拒绝非HTTPS重定向")
		}
		h := req.URL.Hostname()
		if h != "github.com" && h != "release-assets.githubusercontent.com" && h != "objects.githubusercontent.com" {
			return errors.New("拒绝非官方资产主机")
		}
		return nil
	}}
	fmt.Println("正在从官方 GitHub 下载固定版本；下载失败不会运行任何文件。")
	res, e := cli.Get(coreURL)
	if e != nil {
		return errors.New("官方下载失败；请检查网络，程序不会改用第三方镜像")
	}
	defer res.Body.Close()
	if res.StatusCode != 200 {
		return fmt.Errorf("下载返回 HTTP %d", res.StatusCode)
	}
	b, e := io.ReadAll(io.LimitReader(res.Body, 150<<20))
	if e != nil {
		return e
	}
	h := sha256.Sum256(b)
	if hex.EncodeToString(h[:]) != archiveHash {
		return errors.New("官方压缩包SHA256不符，拒绝解压")
	}
	z, e := zip.NewReader(bytes.NewReader(b), int64(len(b)))
	if e != nil {
		return e
	}
	for _, f := range z.File {
		if f.Name == "sing-box-1.14.4-windows-amd64/sing-box.exe" {
			if f.UncompressedSize64 > 200<<20 {
				return errors.New("异常可执行文件大小")
			}
			r, e := f.Open()
			if e != nil {
				return e
			}
			x, e := io.ReadAll(io.LimitReader(r, 200<<20))
			r.Close()
			if e != nil {
				return e
			}
			s := sha256.Sum256(x)
			if hex.EncodeToString(s[:]) != coreHash {
				return errors.New("内核SHA256不符")
			}
			if e = os.MkdirAll(filepath.Dir(exePath()), 0700); e != nil {
				return e
			}
			if _, e = os.Stat(exePath()); e == nil {
				return errors.New("内核文件已存在但未通过校验；保留现场并停止，请勿忽略此错误")
			}
			if e = writeNew(exePath(), x); e != nil {
				return e
			}
			fmt.Println("下载与双重 SHA256 校验完成。没有运行或安装内核。来源：", coreURL)
			return nil
		}
	}
	return errors.New("官方压缩包未包含预期文件")
}
func checkRole(role string) error {
	p, e := verifiedCore()
	if e != nil {
		return e
	}
	if role == "client" {
		if e = refreshClient(); e != nil {
			return e
		}
	}
	dir := filepath.Join(stateDir(), role)
	c := exec.Command(p, "check", "-c", "config.json")
	c.Dir = dir
	c.Stdout = os.Stdout
	c.Stderr = os.Stderr
	return c.Run()
}
func checkAll() error {
	found := false
	for _, role := range []string{"server", "client"} {
		if _, e := os.Stat(filepath.Join(stateDir(), role, "config.json")); e == nil {
			found = true
			if e = checkRole(role); e != nil {
				return e
			}
			fmt.Println(role, "配置检查通过")
		}
	}
	if !found {
		return errors.New("尚未生成或导入配置")
	}
	return nil
}
func runCore(role string) error {
	if e := checkRole(role); e != nil {
		return e
	}
	p, e := verifiedCore()
	if e != nil {
		return e
	}
	fmt.Println("运行中。关闭本窗口或按 Ctrl+C 停止；没有注册开机启动或服务。")
	if role == "server" {
		fmt.Println("服务端不会改变默认路由、DNS、系统代理或远控设置。")
	}
	c := exec.Command(p, "run", "--disable-color", "-c", filepath.Join(stateDir(), role, "config.json"))
	c.Dir = filepath.Join(stateDir(), role)
	c.Stdout = os.Stdout
	c.Stderr = os.Stderr
	c.Stdin = os.Stdin
	if e = c.Start(); e != nil {
		return e
	}
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt)
	defer signal.Stop(sig)
	done := make(chan error, 1)
	go func() { done <- c.Wait() }()
	select {
	case e = <-done:
		return e
	case <-sig:
		select {
		case <-done:
			return nil
		case <-time.After(3 * time.Second):
			_ = c.Process.Kill()
			<-done
			return nil
		}
	}
}
func diagnose() error {
	if e := checkAll(); e != nil {
		return e
	}
	v, e := readInvite(filepath.Join(stateDir(), "client", "connection.SECRET.json"))
	if e != nil {
		if os.IsNotExist(e) {
			fmt.Println("本机仅有服务端资料；配置检查完成。公网可达性仍需从中国测试。")
			return nil
		}
		return e
	}
	pool := x509.NewCertPool()
	pool.AppendCertsFromPEM([]byte(v.Certificate))
	d := &net.Dialer{Timeout: 10 * time.Second}
	c, e := tls.DialWithDialer(d, "tcp", net.JoinHostPort(v.Host, strconv.Itoa(v.Port)), &tls.Config{RootCAs: pool, ServerName: certName, MinVersion: tls.VersionTLS12})
	if e != nil {
		return fmt.Errorf("服务器TLS连接未通过：%w", e)
	}
	c.Close()
	fmt.Println("已从当前电脑连接到配置的服务器，证书与主机名通过校验。这不是吞吐测试，也不证明浏览器或 Codex 已正确分流。")
	return nil
}
func proxyReady(port int) error {
	if _, e := verifiedCore(); e != nil {
		return e
	}
	c, e := net.DialTimeout("tcp", fmt.Sprintf("127.0.0.1:%d", port), time.Second)
	if e != nil {
		return errors.New("本地代理未启动；请先选菜单 5，并保持运行窗口打开")
	}
	c.Close()
	return verifyListenerOwner(port)
}
func browser(address string, rules bool) error {
	u, e := url.Parse(address)
	if e != nil || (u.Scheme != "https" && u.Scheme != "http") || u.Hostname() == "" || u.User != nil {
		return errors.New("只接受不带账号密码的 HTTP/HTTPS 地址")
	}
	port := 2081
	profile := "edge-canada"
	if rules {
		port = 2080
		profile = "edge-rules"
	}
	if e = proxyReady(port); e != nil {
		return e
	}
	path, e := findEdge()
	if e != nil {
		return e
	}
	args := []string{"--user-data-dir=" + filepath.Join(stateDir(), profile), fmt.Sprintf("--proxy-server=http://127.0.0.1:%d", port), "--proxy-bypass-list=<-loopback>;localhost;127.0.0.1;[::1]", "--disable-quic", "--force-webrtc-ip-handling-policy=disable_non_proxied_udp", "--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE localhost", "--disable-background-networking", "--disable-extensions", "--no-first-run", "--new-window", address}
	c := exec.Command(path, args...)
	if e = c.Start(); e != nil {
		return e
	}
	go c.Wait()
	fmt.Println("已请求启动独立 Edge。请关闭该窗口后再停止代理；不要在这个资料目录手动启动无代理的 Edge。")
	fmt.Println("这些浏览器参数尚未在你的 Edge 版本做抓包验收，不等于系统级断网保护。")
	return nil
}
func launchDesktop(path string) error {
	if runtime.GOOS != "windows" {
		return errors.New("仅支持 Windows 桌面启动试验")
	}
	if !filepath.IsAbs(path) || !strings.EqualFold(filepath.Ext(path), ".exe") {
		return errors.New("必须提供实际桌面程序的绝对 .exe 路径，不接受快捷方式或脚本")
	}
	fi, e := os.Stat(path)
	if e != nil || fi.IsDir() {
		return errors.New("指定的程序不存在")
	}
	if e = proxyReady(2081); e != nil {
		return e
	}
	c := exec.Command(path)
	c.Env = proxyEnvironment(os.Environ())
	if e = c.Start(); e != nil {
		return e
	}
	go c.Wait()
	fmt.Println("已尝试以仅本次进程环境的 HTTP(S) 代理启动。没有设置系统代理、没有编辑 Codex 配置。")
	fmt.Println("未证明桌面全部流量经加拿大：已运行进程、商店应用重激活、WSL、插件及内部浏览器可能不继承。必须实际验收，不能将此当作防泄漏模式。")
	return nil
}
func proxyEnvironment(base []string) []string {
	out := []string{}
	for _, s := range base {
		k := strings.ToUpper(strings.SplitN(s, "=", 2)[0])
		if k == "HTTP_PROXY" || k == "HTTPS_PROXY" || k == "ALL_PROXY" || k == "NO_PROXY" {
			continue
		}
		out = append(out, s)
	}
	for _, k := range []string{"HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy"} {
		out = append(out, k+"=http://127.0.0.1:2081")
	}
	return append(out, "NO_PROXY=localhost,127.0.0.1,::1", "no_proxy=localhost,127.0.0.1,::1")
}

func atomicWrite(path string, b []byte) error {
	f, e := os.CreateTemp(filepath.Dir(path), ".config-*.tmp")
	if e != nil {
		return e
	}
	name := f.Name()
	defer os.Remove(name)
	if e = f.Chmod(0600); e == nil {
		_, e = f.Write(b)
	}
	if e == nil {
		e = f.Sync()
	}
	ce := f.Close()
	if e != nil {
		return e
	}
	if ce != nil {
		return ce
	}
	return os.Rename(name, path)
}
