package main

import (
	"crypto/rand"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func fixture(t *testing.T) Invite {
	t.Helper()
	cert, _, expiry, e := certPair()
	if e != nil {
		t.Fatal(e)
	}
	p := make([]byte, 32)
	rand.Read(p)
	return Invite{1, "vpn.example.com", 443, base64.RawURLEncoding.EncodeToString(p), cert, expiry.Format("2006-01-02T15:04:05Z07:00")}
}
func TestHostValidation(t *testing.T) {
	for _, h := range []string{"vpn.example.com", "203.0.113.1", "2001:db8::1"} {
		if !validHost(h) {
			t.Error(h)
		}
	}
	for _, h := range []string{"", "https://x.com", "x.com;cmd", "x.com/a", "x.com\nfoo", "*.x.com", "-x.com", "localhost", "x..com", "x.com:443"} {
		if validHost(h) {
			t.Error(h)
		}
	}
}
func TestCertificateNameAndLifetime(t *testing.T) {
	v := fixture(t)
	if e := validateInvite(v); e != nil {
		t.Fatal(e)
	}
	b, _ := pem.Decode([]byte(v.Certificate))
	c, e := x509.ParseCertificate(b.Bytes)
	if e != nil {
		t.Fatal(e)
	}
	if e = c.VerifyHostname(certName); e != nil {
		t.Fatal(e)
	}
	if e = c.VerifyHostname("attacker.example"); e == nil {
		t.Fatal("wrong name accepted")
	}
	if c.NotAfter.Sub(c.NotBefore).Hours() > 24*367 {
		t.Fatal("unexpected lifetime")
	}
}
func TestInviteRejectsInvalid(t *testing.T) {
	v := fixture(t)
	for _, mutate := range []func(*Invite){func(x *Invite) { x.Password = "weak" }, func(x *Invite) { x.Port = 0 }, func(x *Invite) { x.Port = 65536 }, func(x *Invite) { x.Version = 2 }, func(x *Invite) { x.Certificate += "junk" }, func(x *Invite) { x.Host = "https://example.com" }} {
		bad := v
		mutate(&bad)
		if validateInvite(bad) == nil {
			t.Fatal("invalid invite accepted")
		}
	}
}
func TestInviteStrictJSON(t *testing.T) {
	v := fixture(t)
	d := t.TempDir()
	p := filepath.Join(d, "x.json")
	m := M{}
	json.Unmarshal(jsonBytes(v), &m)
	m["command"] = "anything"
	os.WriteFile(p, jsonBytes(m), 0600)
	if _, e := readInvite(p); e == nil {
		t.Fatal("unknown field accepted")
	}
	os.WriteFile(p, append(jsonBytes(v), []byte("{}")...), 0600)
	if _, e := readInvite(p); e == nil {
		t.Fatal("trailing object accepted")
	}
}
func TestNoPrivateKeyInInvite(t *testing.T) {
	v := fixture(t)
	if strings.Contains(string(jsonBytes(v)), "PRIVATE KEY") {
		t.Fatal("private key leaked")
	}
}
func TestClientNoInsecureOrTUN(t *testing.T) {
	b := string(jsonBytes(clientConfig(fixture(t), defaultDomains)))
	for _, x := range []string{"\"insecure\"", "\"tun\"", "\"auto_route\"", "\"system_proxy\"", "0.0.0.0"} {
		if strings.Contains(b, x) {
			t.Fatal("unsafe default", x)
		}
	}
	if !strings.Contains(b, "127.0.0.1") {
		t.Fatal("not loopback")
	}
}
func TestClientForceRouteFirst(t *testing.T) {
	cfg := clientConfig(fixture(t), defaultDomains)
	r := cfg["route"].(M)
	rules := r["rules"].([]M)
	if rules[0]["outbound"] != "canada" || rules[0]["inbound"].([]string)[0] != "canada-only" {
		t.Fatal("forced route missing")
	}
	if r["final"] != "direct" {
		t.Fatal("domestic default changed")
	}
}
func TestServerNoNetworkMutation(t *testing.T) {
	b := string(jsonBytes(serverConfig(fixture(t), 24443, "192.168.1.10")))
	for _, x := range []string{"\"tun\"", "\"auto_route\"", "\"system_proxy\""} {
		if strings.Contains(b, x) {
			t.Fatal("network mutation", x)
		}
	}
	if !strings.Contains(b, "\"reject\"") {
		t.Fatal("no deny rules")
	}
}
func TestServerResolveBeforeDeny(t *testing.T) {
	r := serverConfig(fixture(t), 24443, "192.168.1.10")["route"].(M)["rules"].([]M)
	if r[1]["action"] != "resolve" || r[2]["action"] != "reject" {
		t.Fatal("DNS destination validation order")
	}
	for _, x := range []string{"100.64.0.0/10", "127.0.0.0/8", "169.254.0.0/16", "fc00::/7", "fe80::/10", "::ffff:0:0/96"} {
		if !strings.Contains(strings.Join(blockedIPs, ","), x) {
			t.Fatal("missing block", x)
		}
	}
}
func TestDomainListRejectsURLsAndEmpty(t *testing.T) {
	p := filepath.Join(t.TempDir(), "domains.txt")
	for _, s := range []string{"", "# comment\n", "https://x.com", "*.x.com", "127.0.0.1"} {
		os.WriteFile(p, []byte(s), 0600)
		if _, e := loadDomains(p); e == nil {
			t.Fatal("invalid domain list", s)
		}
	}
	os.WriteFile(p, []byte("ChatGPT.com\nchatgpt.com\n# skip\nopenai.com\n"), 0600)
	d, e := loadDomains(p)
	if e != nil || len(d) != 2 {
		t.Fatal(d, e)
	}
}
func TestProxyEnvScopedAndReplaced(t *testing.T) {
	base := []string{"PATH=x", "HTTPS_PROXY=http://bad", "http_proxy=http://bad", "NO_PROXY=*"}
	out := proxyEnvironment(base)
	s := strings.Join(out, "\n")
	if strings.Contains(s, "bad") || strings.Contains(s, "NO_PROXY=*") {
		t.Fatal(s)
	}
	if base[1] != "HTTPS_PROXY=http://bad" {
		t.Fatal("mutated caller environment")
	}
	if !strings.Contains(s, "HTTPS_PROXY=http://127.0.0.1:2081") {
		t.Fatal(s)
	}
}
func TestWriteNewDoesNotOverwrite(t *testing.T) {
	p := filepath.Join(t.TempDir(), "a")
	if e := writeNew(p, []byte("first")); e != nil {
		t.Fatal(e)
	}
	if e := writeNew(p, []byte("second")); e == nil {
		t.Fatal("overwritten")
	}
	b, _ := os.ReadFile(p)
	if string(b) != "first" {
		t.Fatal("mutated")
	}
}
func TestSetupAndImportNoOverwrite(t *testing.T) {
	t.Setenv("CANADALINK_HOME", t.TempDir())
	if e := setupServer("vpn.example.com", 443, 24443, "127.0.0.1"); e != nil {
		t.Fatal(e)
	}
	p := filepath.Join(stateDir(), "server", "client-connection.SECRET.json")
	if e := importClient(p); e != nil {
		t.Fatal(e)
	}
	if e := importClient(p); e == nil {
		t.Fatal("import overwrite")
	}
	if e := setupServer("vpn.example.com", 443, 24443, "127.0.0.1"); e == nil {
		t.Fatal("server overwrite")
	}
}
