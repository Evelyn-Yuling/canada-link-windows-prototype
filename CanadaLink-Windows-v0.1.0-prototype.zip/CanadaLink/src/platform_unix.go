//go:build !windows

package main

import "errors"

func setupConsole()                    {}
func spawnWindow(command string) error { return errors.New("此功能仅用于 Windows") }
func findEdge() (string, error)        { return "", errors.New("此功能仅用于 Windows") }

func verifyListenerOwner(port int) error {
	return errors.New("监听进程身份验证仅在 Windows 实现")
}
