package main

import (
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"syscall"
	"time"
)

func setupConsole() {
	k := syscall.NewLazyDLL("kernel32.dll")
	k.NewProc("SetConsoleOutputCP").Call(65001)
	k.NewProc("SetConsoleCP").Call(65001)
}
func spawnWindow(command string) error {
	p, e := os.Executable()
	if e != nil {
		return e
	}
	c := exec.Command(p, command)
	c.SysProcAttr = &syscall.SysProcAttr{CreationFlags: 0x00000010}
	if e = c.Start(); e != nil {
		return e
	}
	go c.Wait()
	return nil
}
func findEdge() (string, error) {
	for _, base := range []string{os.Getenv("ProgramFiles(x86)"), os.Getenv("ProgramFiles"), os.Getenv("LOCALAPPDATA")} {
		p := filepath.Join(base, "Microsoft", "Edge", "Application", "msedge.exe")
		if s, e := os.Stat(p); e == nil && !s.IsDir() {
			return p, nil
		}
	}
	return "", errors.New("未找到 Edge；本原型不会自动安装浏览器")
}

func verifyListenerOwner(port int) error {
	script := `$ErrorActionPreference='Stop'; $ids=@(Get-NetTCPConnection -State Listen -LocalAddress 127.0.0.1 -LocalPort ` + strconv.Itoa(port) + ` | Select-Object -ExpandProperty OwningProcess -Unique); if($ids.Count -ne 1){exit 20}; $p=Get-CimInstance Win32_Process -Filter ('ProcessId='+$ids[0]); if(-not [string]::Equals($p.ExecutablePath,$env:CANADALINK_CORE,[StringComparison]::OrdinalIgnoreCase)){exit 21}; if(-not $p.CommandLine -or $p.CommandLine.IndexOf($env:CANADALINK_CONFIG,[StringComparison]::OrdinalIgnoreCase) -lt 0){exit 22}; exit 0`
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, "powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script)
	cmd.Env = append(os.Environ(), "CANADALINK_CORE="+exePath(), "CANADALINK_CONFIG="+filepath.Join(stateDir(), "client", "config.json"))
	if e := cmd.Run(); e != nil {
		return fmt.Errorf("无法确认端口属于本工具的已校验内核，已拒绝启动应用；请检查代理窗口及端口冲突（%v）", e)
	}
	return nil
}
