"""Local Linux integration tests of the real official sing-box core.

No user machine or external service is used. Positive transport fixtures allow
loopback deliberately; production configuration is tested separately to deny it.
This does NOT test Windows, Edge, Codex, or China--Canada network performance.
"""
import copy
import hashlib
import http.server
import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import threading
import time

ROOT = Path(__file__).resolve().parents[1]
CORE = ROOT / 'tools/sing-box-1.14.4-linux-amd64/sing-box'
HELPER = ROOT / 'tools/canada-link-test'
results = []
procs = []

def freeport():
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]

def passed(name):
    results.append(name)
    print('PASS', name, flush=True)

def start(config, folder, name):
    path = folder / (name + '.json')
    path.write_text(json.dumps(config))
    subprocess.run([str(CORE), 'check', '-c', str(path)], cwd=folder, check=True, capture_output=True)
    log = open(folder / (name + '.log'), 'wb')
    p = subprocess.Popen([str(CORE), 'run', '-c', str(path)], cwd=folder, stdout=log, stderr=log)
    procs.append((p, log))
    time.sleep(.15)
    assert p.poll() is None, (folder / (name + '.log')).read_text()
    return p

def fetch(proxyport, url, data=None):
    args = ['curl', '--silent', '--show-error', '--fail', '--max-time', '3', '--noproxy', '',
            '--proxy', f'http://127.0.0.1:{proxyport}', url]
    if data is not None:
        args += ['--data-binary', '@-']
    return subprocess.run(args, input=data, capture_output=True)

class Origin(http.server.BaseHTTPRequestHandler):
    count = 0
    def do_GET(self):
        Origin.count += 1
        b = b'origin-through-proxy\n'
        self.send_response(200)
        self.send_header('Content-Length', str(len(b)))
        self.end_headers()
        self.wfile.write(b)
    def do_POST(self):
        Origin.count += 1
        b = self.rfile.read(int(self.headers['Content-Length']))
        b = hashlib.sha256(b).hexdigest().encode()
        self.send_response(200)
        self.send_header('Content-Length', str(len(b)))
        self.end_headers()
        self.wfile.write(b)
    def log_message(self, *args):
        pass

try:
    with tempfile.TemporaryDirectory(prefix='canadalink-integration-') as tmp:
        base = Path(tmp)
        origin = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Origin)
        threading.Thread(target=origin.serve_forever, daemon=True).start()
        op = origin.server_port
        sp, cp1, cp2 = freeport(), freeport(), freeport()
        env = dict(os.environ, CANADALINK_HOME=str(base / 'state'))
        subprocess.run([str(HELPER), 'setup-server', '127.0.0.1', str(sp), str(sp), '127.0.0.1'], env=env, check=True, capture_output=True)
        serverdir = base / 'state/server'
        subprocess.run([str(HELPER), 'import-client', str(serverdir/'client-connection.SECRET.json')], env=env, check=True, capture_output=True)
        clientdir = base / 'state/client'
        production = json.loads((serverdir/'config.json').read_text())
        client = json.loads((clientdir/'config.json').read_text())
        client['inbounds'][0]['listen_port'] = cp1
        client['inbounds'][1]['listen_port'] = cp2
        prod = start(production, serverdir, 'production')
        cli = start(client, clientdir, 'client')
        passed('generated production server and client pass real core schema check and start')
        # Requests that must not reach the local origin through the server.
        for host in ('127.0.0.1', 'localhost', '[::1]', '[::ffff:127.0.0.1]', '169.254.169.254', '100.64.0.1', '10.0.0.1', '[fc00::1]'):
            before = Origin.count
            r = fetch(cp2, f'http://{host}:{op}/')
            assert r.returncode != 0 and Origin.count == before, (host,r.stdout,r.stderr)
        passed('production rejects loopback, resolved localhost, mapped IPv6, ULA, CGNAT, RFC1918 and link-local')
        r = fetch(cp1, f'http://127.0.0.1:{op}/')
        assert r.returncode == 0 and r.stdout == b'origin-through-proxy\n', (r.stdout,r.stderr)
        passed('unlisted destination on split listener goes direct')
        prod.terminate();prod.wait(timeout=3)
        # Loopback-only transport test fixture, NOT the distributed production config.
        fixture = copy.deepcopy(production)
        fixture['dns']['servers'] = [{'type':'hosts','tag':'local-dns','predefined':{'only-on-server.invalid':'127.0.0.1'}}]
        fixture['route']['rules'].insert(2, {'ip_cidr':['127.0.0.1/32'],'action':'route','outbound':'residential'})
        srv = start(fixture, serverdir, 'loopback-only-fixture')
        r = fetch(cp2, f'http://only-on-server.invalid:{op}/')
        assert r.returncode == 0 and r.stdout == b'origin-through-proxy\n', (r.stdout,r.stderr)
        passed('TLS/authenticated proxy tunnel transfers data with destination DNS resolved only on server fixture')
        payload = os.urandom(2*1024*1024)
        r = fetch(cp2, f'http://only-on-server.invalid:{op}/', payload)
        assert r.returncode == 0 and r.stdout.decode() == hashlib.sha256(payload).hexdigest(), r.stderr
        passed('2 MiB upload through real proxy core preserves content')
        for kind in ('password','hostname','certificate'):
            bad = copy.deepcopy(client)
            port = freeport()
            bad['inbounds'] = [dict(bad['inbounds'][1], listen_port=port)]
            if kind == 'password':
                bad['outbounds'][0]['password'] = 'wrong-password'
            elif kind == 'hostname':
                bad['outbounds'][0]['tls']['server_name'] = 'wrong.invalid'
            else:
                env2 = dict(os.environ, CANADALINK_HOME=str(base/'other'))
                subprocess.run([str(HELPER), 'setup-server', 'vpn.example.com','443','24443','127.0.0.1'],env=env2,check=True,capture_output=True)
                bad['outbounds'][0]['tls']['certificate'] = [(base/'other/server/server-cert.pem').read_text()]
            start(bad,clientdir,'bad-'+kind)
            before = Origin.count
            r = fetch(port,f'http://only-on-server.invalid:{op}/')
            assert r.returncode != 0 and Origin.count == before, (kind,r.stdout,r.stderr)
            passed('wrong '+kind+' fails closed')
        srv.terminate();srv.wait(timeout=3)
        before = Origin.count
        r = fetch(cp2,f'http://127.0.0.1:{op}/')
        assert r.returncode != 0 and Origin.count == before
        passed('forced proxy does not fall back to direct when remote server is down')
        r = fetch(cp1,f'http://127.0.0.1:{op}/')
        assert r.returncode == 0
        passed('unlisted direct route still works while remote server is down')
        cli.terminate();cli.wait(timeout=3)
        r = fetch(cp2,f'http://127.0.0.1:{op}/')
        assert r.returncode != 0
        passed('fixed explicit proxy request fails when local proxy is down')
        origin.shutdown()
        print(json.dumps({'local_linux_integration':'passed','cases':results,'not_tested':['Windows runtime','Edge packet capture','Codex desktop','WSL','China-Canada route','real residential egress','DNS rebinding adversarial matrix','HTTP2/WebSocket'],'at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())},ensure_ascii=False,indent=2))
finally:
    for p,log in procs:
        if p.poll() is None:
            p.terminate()
            try:p.wait(timeout=3)
            except subprocess.TimeoutExpired:p.kill();p.wait()
        log.close()
